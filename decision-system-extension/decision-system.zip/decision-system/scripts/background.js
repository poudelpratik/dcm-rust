// runs in the background to check browser actions/events

// chrome.runtime.onInstalled.addListener((details) => {
//   console.log("previousVersion", details.previousVersion);
// });
// console.log("Event Page for Page Action");
