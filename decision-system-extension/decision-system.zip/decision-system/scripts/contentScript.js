// gets injected into specified/allowed sites

// console.log("Content script");
// let topDiv = document.createElement("div");
// topDiv.setAttribute("class", "content-top-div");
// topDiv.innerText = "This div is added by My first chrome extension.";
// document.body.appendChild(topDiv);
